from django.contrib import admin
from django.urls import path

from payer import views as payer
from fund import views as fund
from refund import views as refund
from record import views as record
urlpatterns = [
path('admin/', admin.site.urls),
path('payer/info',payer.info,name='info'),
path('payer/delete',payer.delete,name='delete'),
path('payer/list',payer.list,name='list'),
path('payer/save',payer.save,name='save'),
path('payer/update',payer.update,name='update'),
path('payer/page',payer.page,name='pag'),
path('payer/login',payer.login,name='login'),
path('fund/info',fund.info,name='info'),
path('fund/delete',fund.delete,name='delete'),
path('fund/list',fund.list,name='list'),
path('fund/save',fund.save,name='save'),
path('fund/update',fund.update,name='update'),
path('fund/page',fund.page,name='pag'),
path('fund/pay',fund.pay,name='pay'),
path('fund/exitMoney',fund.exitMoney,name='exitMoney'),
path('record/info',record.info,name='info'),
path('record/delete',record.delete,name='delete'),
path('record/list',record.list,name='list'),
path('record/save',record.save,name='save'),
path('record/update',record.update,name='update'),
path('record/page',record.page,name='pag'),
path('refund/info',refund.info,name='info'),
path('refund/delete',refund.delete,name='delete'),
path('refund/list',refund.list,name='list'),
path('refund/save',refund.save,name='save'),
path('refund/update',refund.update,name='update'),
path('refund/page',refund.page,name='pag'),
]
