import json

from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import HttpResponse
from datetime import datetime
from payer.models import Payer
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage


def list(request):
    resquest_payer = Payer.objects.filter().all()
    resquest_List = []
    for n_payer in resquest_payer:
        Dir = {'id': n_payer.id, 'name': n_payer.name, 'create_time': n_payer.create_time, 'status': n_payer.status,
               'reserve1': n_payer.reserve1, 'reserve2': n_payer.reserve2, 'reserve3': n_payer.reserve3,
               'reserve4': n_payer.reserve4, 'reserve5': n_payer.reserve5, 'password': n_payer.password,
               'username': n_payer.username}
        resquest_List.append(Dir)
    content = {
        'success': True,
        'message': '查询成功',
        'data': resquest_List
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def info(request):
    query_dict = request.GET
    id = query_dict.get('id')
    request = Payer.objects.get(id=id)
    new_request = {'id': request.id, 'name': request.name, 'create_time': request.create_time, 'status': request.status,
                   'reserve1': request.reserve1, 'reserve2': request.reserve2, 'reserve3': request.reserve3,
                   'reserve4': request.reserve4, 'reserve5': request.reserve5, 'password': request.password,
                   'username': request.username}
    content = {
        'success': True,
        'message': '查询成功',
        'data': new_request
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def delete(request):
    query_dict = request.GET
    id = query_dict.get('id')
    re = Payer.objects.get(id=id).delete()
    content = {
        'success': True,
        'message': '删除成功',
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    payer = Payer()
    fields = ['name', 'status', 'reserve1', 'reserve2', 'reserve3', 'reserve4', 'reserve5', 'password', 'username']
    for field in fields:
        try:
            setattr(payer, field, jsonData[field])
        except Exception:
            print(f"{field} is null")
    payer.create_time = now
    payer.save()
    content = {
        'success': True,
        'message': '新增成功',
        'data': jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def update(request):
    jsonData = json.loads(request.body.decode())
    payer_id = jsonData['id']

    try:
        payer = Payer.objects.get(id=payer_id)
    except Payer.DoesNotExist:
        content = {
            'success': False,
            'message': f'Payer with id {payer_id} does not exist',
        }
        return JsonResponse(content, safe=False)

    # List of fields
    fields = ['name', 'status', 'reserve1', 'reserve2', 'reserve3', 'reserve4', 'reserve5', 'password', 'username']
    for field in fields:
        if field in jsonData:
            setattr(payer, field, jsonData[field])

    payer.save()
    content = {
        'success': True,
        'message': '修改成功',
        'data': jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def page(request):
    data = json.loads(request.body.decode())
    pageNum = data['pageNum']
    pagesize = data['pageSize']
    search = data['search']
    res1 = []
    if search:
        res1 = Payer.objects.filter(name=search)
    else:
        res1 = Payer.objects.filter()
    total = res1.count()
    p = Paginator(res1, pagesize)
    page = []
    try:
        page = p.page(pageNum)
    except PageNotAnInteger:
        page = p.page(pageNum)
    except EmptyPage:
        page = p.page(pageNum)
    resList = []
    for p in page:
        Dir = {}
        Dir['id'] = p.id
        Dir['name'] = p.name
        Dir['create_time'] = p.create_time
        Dir['status'] = p.status
        Dir['reserve1'] = p.reserve1
        Dir['reserve2'] = p.reserve2
        Dir['reserve3'] = p.reserve3
        Dir['reserve4'] = p.reserve4
        Dir['reserve5'] = p.reserve5
        Dir['password'] = p.password
        Dir['username'] = p.username
        resList.append(Dir)
    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': total
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def login(request):
    jsonData = json.loads(request.body.decode())
    res1 = Payer.objects.filter(username=jsonData['username']).all()
    content = {}
    if len(res1) > 0:
        res2 = Payer.objects.filter(username=jsonData['username'], password=jsonData['password'])
        res3 = {
            "username": res1[0].username,
            "name": res1[0].name,
            "role": 'payer',

        }
        if len(res2) > 0:
            content = {
                'success': True,
                'message': '登录成功',
                'data': res3
            }
        else:
            content = {
                'success': False,
                'message': '密码错误'
            }
    else:
        content = {
            'success': False,
            'message': '用户不存在'
        }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')
