import json

from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import HttpResponse
from datetime import datetime
from fund.models import Fund
from record.models import Record
from refund.models import Refund
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage


def list(request):
    resquest_fund = Fund.objects.filter().all()
    resquest_List = []
    for n_found in resquest_fund:
        Dir = {'id': n_found.id, 'name': n_found.name, 'create_time': n_found.create_time, 'status': n_found.status,
               'reserve1': n_found.reserve1, 'reserve2': n_found.reserve2, 'reserve3': n_found.reserve3,
               'reserve4': n_found.reserve4, 'reserve5': n_found.reserve5, 'balance': n_found.balance,
               'bank': n_found.bank}
        resquest_List.append(Dir)
    content = {
        'success': True,
        'message': '查询成功',
        'data': resquest_List
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def info(request):
    query_dict = request.GET
    id = query_dict.get('id')
    request = Fund.objects.get(id=id)
    new_request = {'id': request.id, 'name': request.name, 'create_time': request.create_time, 'status': request.status,
                   'reserve1': request.reserve1, 'reserve2': request.reserve2, 'reserve3': request.reserve3,
                   'reserve4': request.reserve4, 'reserve5': request.reserve5, 'balance': request.balance,
                   'bank': request.bank}
    content = {
        'success': True,
        'message': '查询成功',
        'data': new_request
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def delete(request):
    query_dict = request.GET
    delete_id = query_dict.get('id')
    re = Fund.objects.get(id=delete_id).delete()
    content = {
        'success': True,
        'message': '删除成功',
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    re = Fund.objects.filter(name=jsonData['name'], reserve2=jsonData['reserve2']).all()
    if (len(re) > 0):
        content = {
            'success': False,
            'message': '资金账户已存在',

        }
        return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
    fund = Fund()
    fields = ['name', 'status', 'reserve1', 'reserve2', 'reserve3', 'reserve4', 'reserve5', 'balance', 'bank']
    for field in fields:
        try:
            setattr(fund, field, jsonData[field])
        except Exception:
            print(f"{field} is null")
    fund.create_time = now
    fund.save()
    content = {
        'success': True,
        'message': '新增成功',
        'data': jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def update(request):
    jsonData = json.loads(request.body.decode())
    fund_id = jsonData['id']
    try:
        fund = Fund.objects.get(id=fund_id)
    except Fund.DoesNotExist:
        content = {
            'success': False,
            'message': f'Fund with id {fund_id} does not exist',
        }
        return JsonResponse(content, safe=False)

        # List of fields
    fields = ['name', 'status', 'reserve1', 'reserve2', 'reserve3', 'reserve4', 'reserve5', 'balance', 'bank']
    for field in fields:
        if field in jsonData:
            setattr(fund, field, jsonData[field])
    fund.save()
    content = {
        'success': True,
        'message': '修改成功',
        'data': jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def page(request):
    data = json.loads(request.body.decode())
    pageNum = data['pageNum']
    pagesize = data['pageSize']
    search = data['search']
    res1 = []
    if search:
        res1 = Fund.objects.filter(name=search)
    else:
        res1 = Fund.objects.filter()
    total = res1.count()
    p = Paginator(res1, pagesize)
    page = []
    try:
        page = p.page(pageNum)
    except PageNotAnInteger:
        page = p.page(pageNum)
    except EmptyPage:
        page = p.page(pageNum)
    resList = []
    for request in page:
        Dir = {}
        Dir['id'] = request.id
        Dir['name'] = request.name
        Dir['create_time'] = request.create_time
        Dir['status'] = request.status
        Dir['reserve1'] = request.reserve1
        Dir['reserve2'] = request.reserve2
        Dir['reserve3'] = request.reserve3
        Dir['reserve4'] = request.reserve4
        Dir['reserve5'] = request.reserve5
        Dir['balance'] = request.balance
        Dir['bank'] = request.bank
        resList.append(Dir)
    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': total
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def pay(request):
    jsonData = json.loads(request.body.decode())
    name = jsonData['name']
    reserve2 = jsonData['reserve2']
    payNum = jsonData['payNum']
    try:
        re = Fund.objects.get(name=name, reserve2=reserve2)
    except Exception:
        content = {
            'success': False,
            'message': '资金账户不存在',
        }
        return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
    re = Fund.objects.get(name=name, reserve2=reserve2)
    blan = int(re.balance)
    if (payNum > blan):
        content = {
            'success': False,
            'message': '余额不足',
        }
        return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')
    else:
        re.balance = blan - payNum
        re.save()
        content = {
            'success': True,
            'message': '支付成功',
        }
        record = Record()
        record.bank = re.reserve1
        record.reserve2 = re.reserve2
        record.content = "支付" + str(payNum)
        print(record.content)
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        record.create_time = now
        record.name = name
        record.save()
        return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')


def exitMoney(request):
    jsonData = json.loads(request.body.decode())
    name = jsonData['name']
    reserve2 = jsonData['reserve2']
    payNum = jsonData['payNum']
    re = Fund.objects.get(name=name, reserve2=reserve2)
    blan = int(re.balance)
    re.balance = blan + payNum
    re.save()
    content = {
        'success': True,
        'message': '退钱成功',
    }
    refund = Refund()
    refund.bank = re.reserve1
    refund.reserve2 = re.reserve2
    refund.content = "退还" + str(payNum)
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    refund.create_time = now
    refund.name = name
    refund.save()
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')



