from django.test import TestCase
# Create your tests here.
from django.test import TestCase, Client
from django.urls import reverse
from .models import Fund
import json

class FundViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.list_url = reverse('fund:list')
        self.info_url = reverse('fund:info')
        self.delete_url = reverse('fund:delete')
        self.delete_url = reverse('fund:pay')
        self.delete_url = reverse('fund:exitMoney')
        self.delete_url = reverse('fund:save')
        self.delete_url = reverse('fund:update')
        self.delete_url = reverse('fund:page')
        self.fund = Fund.objects.create(
            name='Test Fund',
            status='Test Status',
            reserve1='Test Reserve1',
            reserve2='Test Reserve2',
            reserve3='Test Reserve3',
            reserve4='Test Reserve4',
            reserve5='Test Reserve5',
            balance='Test Balance',
            bank='Test Bank'
        )

    def test_list(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '查询成功')
        self.assertEqual(len(content['data']), 1)
        self.assertEqual(content['data'][0]['name'], 'Test Fund')
        self.assertEqual(content['data'][0]['status'], 'Test Status')

    def test_info(self):
        response = self.client.get(self.info_url, {'id': self.fund.id})
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '查询成功')
        self.assertEqual(content['data']['id'], self.fund.id)
        self.assertEqual(content['data']['name'], 'Test Fund')
        self.assertEqual(content['data']['status'], 'Test Status')

    def test_delete(self):  # Add this function
        response = self.client.get(self.delete_url, {'id': self.fund.id})
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '删除成功')
        # Test that the fund has been deleted
        with self.assertRaises(Fund.DoesNotExist):
            Fund.objects.get(id=self.fund.id)

    def test_pay(self):  # Add this function
        pay_data = {
            'name': 'Test Fund',
            'reserve2': 'Test Reserve2',
            'payNum': 50  # Assume we pay 50
        }
        response = self.client.post(self.pay_url, json.dumps(pay_data), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '支付成功')
        reloaded_fund = Fund.objects.get(id=self.fund.id)
        self.assertEqual(reloaded_fund.balance, 50)

    def test_exit_money(self):
        exit_money_data = {
            'name': 'Test Fund',
            'reserve2': 'Test Reserve2',
            'payNum': 50
        }
        response = self.client.post(self.exit_money_url, json.dumps(exit_money_data),
                                    content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '退钱成功')
        reloaded_fund = Fund.objects.get(id=self.fund.id)
        self.assertEqual(reloaded_fund.balance, 150)

    def test_save(self):
        save_data = {
            'name': 'New Fund',
            'status': 'New Status',
            'reserve1': 'New Reserve1',
            'reserve2': 'New Reserve2',
            'reserve3': 'New Reserve3',
            'reserve4': 'New Reserve4',
            'reserve5': 'New Reserve5',
            'balance': 1000,
            'bank': 'New Bank'
        }
        response = self.client.post(self.save_url, json.dumps(save_data), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '新增成功')
        # Check if the new fund has been saved to database
        fund = Fund.objects.get(name='New Fund', reserve2='New Reserve2')
        self.assertIsNotNone(fund)
        self.assertEqual(fund.status, 'New Status')
        self.assertEqual(fund.reserve1, 'New Reserve1')
        self.assertEqual(fund.reserve3, 'New Reserve3')
        self.assertEqual(fund.reserve4, 'New Reserve4')
        self.assertEqual(fund.reserve5, 'New Reserve5')
        self.assertEqual(fund.balance, 1000)
        self.assertEqual(fund.bank, 'New Bank')

    def test_update(self):
        original_fund = Fund.objects.create(
            name='Original Name',
            status='Original Status',
            reserve1='Original Reserve1',
            reserve2='Original Reserve2',
            reserve3='Original Reserve3',
            reserve4='Original Reserve4',
            reserve5='Original Reserve5',
            balance=1000,
            bank='Original Bank'
        )
        update_data = {
            'id': original_fund.id,
            'name': 'Updated Name',
            'status': 'Updated Status',
            'reserve1': 'Updated Reserve1',
            'reserve2': 'Updated Reserve2',
            'reserve3': 'Updated Reserve3',
            'reserve4': 'Updated Reserve4',
            'reserve5': 'Updated Reserve5',
            'balance': 2000,
            'bank': 'Updated Bank'
        }
        response = self.client.post(self.update_url, json.dumps(update_data), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '修改成功')
        updated_fund = Fund.objects.get(id=original_fund.id)
        self.assertEqual(updated_fund.name, 'Updated Name')
        self.assertEqual(updated_fund.status, 'Updated Status')
        self.assertEqual(updated_fund.reserve1, 'Updated Reserve1')
        self.assertEqual(updated_fund.reserve2, 'Updated Reserve2')
        self.assertEqual(updated_fund.reserve3, 'Updated Reserve3')
        self.assertEqual(updated_fund.reserve4, 'Updated Reserve4')
        self.assertEqual(updated_fund.reserve5, 'Updated Reserve5')
        self.assertEqual(updated_fund.balance, 2000)
        self.assertEqual(updated_fund.bank, 'Updated Bank')

    def test_page(self):
        for i in range(30):
            Fund.objects.create(
                name=f'Fund {i}',
                status='Status',
                reserve1='Reserve1',
                reserve2='Reserve2',
                reserve3='Reserve3',
                reserve4='Reserve4',
                reserve5='Reserve5',
                balance=1000,
                bank='Bank'
            )
        # Prepare the page request data
        page_data = {
            'pageNum': 2,
            'pageSize': 10,
            'search': ''
        }
        # Send the page request
        response = self.client.get(self.page_url, json.dumps(page_data), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '查询成功')
        # Check the returned fund data
        self.assertEqual(len(content['data']), 10)
        self.assertEqual(content['total'], 30)
        for i in range(10):
            self.assertEqual(content['data'][i]['name'], f'Fund {i + 10}')
            self.assertEqual(content['data'][i]['status'], 'Status')
            self.assertEqual(content['data'][i]['reserve1'], 'Reserve1')
            self.assertEqual(content['data'][i]['reserve2'], 'Reserve2')
            self.assertEqual(content['data'][i]['reserve3'], 'Reserve3')
            self.assertEqual(content['data'][i]['reserve4'], 'Reserve4')
            self.assertEqual(content['data'][i]['reserve5'], 'Reserve5')
            self.assertEqual(content['data'][i]['balance'], 1000)
            self.assertEqual(content['data'][i]['bank'], 'Bank')
