from django.test import TestCase

# Create your tests here.
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User  # Assumes that Payer model extends User
import json

class LoginViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.login_url = reverse('login')  # Assumes the url name for the login view is 'login'
        self.test_username = 'testuser'
        self.test_password = 'testpassword'
        self.test_name = 'Test User'
        self.user = User.objects.create_user(username=self.test_username, password=self.test_password)
        self.user.payer.name = self.test_name
        self.user.payer.save()

    def test_login(self):
        # Test login with correct username and password
        response = self.client.post(self.login_url, json.dumps({
            'username': self.test_username,
            'password': self.test_password
        }), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], True)
        self.assertEqual(content['message'], '登录成功')
        self.assertEqual(content['data']['username'], self.test_username)
        self.assertEqual(content['data']['name'], self.test_name)
        self.assertEqual(content['data']['role'], 'payer')

        # Test login with incorrect password
        response = self.client.post(self.login_url, json.dumps({
            'username': self.test_username,
            'password': 'wrongpassword'
        }), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], False)
        self.assertEqual(content['message'], '密码错误')

        # Test login with nonexistent username
        response = self.client.post(self.login_url, json.dumps({
            'username': 'nonexistent',
            'password': self.test_password
        }), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        content = json.loads(response.content)
        self.assertEqual(content['success'], False)
        self.assertEqual(content['message'], '用户不存在')
