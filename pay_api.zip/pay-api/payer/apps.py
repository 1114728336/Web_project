from django.apps import AppConfig


class PayerConfig(AppConfig):
    name = 'payer'
